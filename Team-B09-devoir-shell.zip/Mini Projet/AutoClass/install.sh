#!/bin/bash

ADMIN_USER="root"
if [[ "$USER" != "$ADMIN_USER" ]]; then
    echo "[Error] Only admin users can perform installation."
    exit 104
fi
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/utils/logger.sh"
REQUIRED_TOOLS=("jq" "curl" "python3" "pip" "python3-venv")

log_and_echo INFO "Checking dependencies..."

install_tool() {
    tool=$1
    if command -v apt &>/dev/null; then
        sudo apt update && sudo apt install -y "$tool"
    elif command -v dnf &>/dev/null; then
        sudo dnf install -y "$tool"
    elif command -v pacman &>/dev/null; then
        sudo pacman -Sy "$tool"
    else
        log_and_echo ERROR "Package manager not recognized. Please install $tool manually."
        exit 105
    fi
}

for tool in "${REQUIRED_TOOLS[@]}"; do
    if ! command -v "$tool" &>/dev/null; then
        log_and_echo INFO "$tool is not installed."
        install_tool "$tool"
    else
        log_and_echo INFO "$tool is installed."
    fi
done

if [ -f "requirements.txt" ]; then
    log_and_echo INFO "Installing Python dependencies..."
    [[ -d "$SCRIPT_DIR/venv" ]] || python3 -m venv "$SCRIPT_DIR/venv"
    source "$SCRIPT_DIR/venv/bin/activate"
    pip install -r requirements.txt
fi

TARGET="/usr/local/bin/autoclass"
SOURCE="$(realpath ./autoclass.sh)"

if [ ! -L "$TARGET" ]; then
    log_info "Creating symlink: $TARGET -> $SOURCE"
    sudo ln -s "$SOURCE" "$TARGET"
else
    log_info "Symlink already exists: $TARGET"
fi
log_and_echo INFO "Installation complete. type autoclass -h for help."
