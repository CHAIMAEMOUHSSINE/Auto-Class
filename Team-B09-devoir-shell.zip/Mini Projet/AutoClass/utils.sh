#!/bin/bash

source "$SCRIPT_DIR/utils/logger.sh"

should_refresh_token() {
    if ! [ -f "$SCRIPT_DIR/JSON/.classroom_tokens" ]; then
        log_and_echo ERROR "Token file not found."
        return 0
    fi

    expiry=$(jq -r '.expiry' "$SCRIPT_DIR/JSON/.classroom_tokens")
    if [ "$expiry" = "null" ] || [ -z "$expiry" ]; then
        return 0
    fi

    expiry_ts=$(date -d "$expiry" +%s)
    now_ts=$(date +%s)

    if [ "$((expiry_ts - now_ts))" -lt 60 ]; then
        return 0
    else
        return 1
    fi
}

resolve_course_name_to_id() {
    local course_name="$1"
    local course_id
    local map_file="$SCRIPT_DIR/JSON/course_map.json"

    course_id=$(jq -r --arg name "$course_name" \
        'to_entries[] | select(.key == $name) | .value' <"$map_file")

    if [[ -z "$course_id" ]]; then
        log_and_echo INFO "Course not found in existing map. Refreshing..."
        "$SCRIPT_DIR/utils/list_courses.sh"

        course_id=$(jq -r --arg name "$course_name" \
            'to_entries[] | select(.key == $name) | .value' <"$map_file")

        if [[ -z "$course_id" ]]; then
            log_and_echo INFO "Course '$course_name' not found after refreshing list."
            return 1
        fi
    fi

    echo "$course_id"
    return 0
}

is_within_deadline() {
    local due_date="$1"
    local today epoch_today epoch_due
    today=$(date +%Y-%m-%d)

    epoch_today=$(date -d "$today" +%s)
    epoch_due=$(date -d "$due_date" +%s 2>/dev/null)

    if [[ -z "$epoch_due" ]]; then
        log_and_echo ERROR "Date '$epoch_due' is invalid."
        return 1
    fi

    local seconds_diff=$((epoch_due - epoch_today))
    local days_diff=$((seconds_diff / 86400))

    [[ $days_diff -ge 0 && $days_diff -le $DEADLINE_DAYS ]]
}

is_within_last_n_days() {
    local date_str="$1"
    local n="$2"
    local post_date
    post_date=$(date -d "$date_str" +%s 2>/dev/null)
    [[ -z "$post_date" ]] && return 1

    local cutoff
    cutoff=$(date -d "-$n days" +%s)
    ((post_date >= cutoff))
}

resolve_assignment_index_to_id() {
    local index="$1"
    local course_id="$2"
    local id_file="/tmp/.assignment_map_${course_id}"
    sed -n "$((index + 1))p" "$id_file"
}

upload_file_to_drive() {
    local TOKENS_FILE="$SCRIPT_DIR/JSON/.classroom_tokens"
    local ACCESS_TOKEN
    ACCESS_TOKEN=$(jq -r .token "$TOKENS_FILE")

    local file_path="$1"

    if [[ ! -f "$file_path" ]]; then
        log_and_echo ERROR "File does not exist: $file_path"
        return 1
    fi

    local file_name
    file_name=$(basename "$file_path")

    local mime_type
    mime_type=$(file -b --mime-type "$file_path")

    local metadata="{\"name\": \"$file_name\"}"

    RESPONSE=$(curl -s -X POST \
        -H "Authorization: Bearer $ACCESS_TOKEN" \
        -F "metadata=$metadata;type=application/json;charset=UTF-8" \
        -F "file=@\"$file_path\";type=$mime_type" \
        "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart")

    FILE_ID=$(echo "$RESPONSE" | jq -r '.id')

    if [[ -z "$FILE_ID" || "$FILE_ID" == "null" ]]; then
        log_and_echo ERROR "Upload failed. Response:"
        log_and_echo ERROR "$RESPONSE"
        return 1
    fi

    curl -s -X POST \
        -H "Authorization: Bearer $ACCESS_TOKEN" \
        -H "Content-Type: application/json" \
        -d '{"role": "reader", "type": "anyone"}' \
        "https://www.googleapis.com/drive/v3/files/$FILE_ID/permissions" >/dev/null

    echo "$FILE_ID"
}

get_logged_in_user_id() {
    local response
    local TOKENS_FILE="$SCRIPT_DIR/JSON/.classroom_tokens"
    local ACCESS_TOKEN
    ACCESS_TOKEN=$(jq -r .token "$TOKENS_FILE")
    response=$(curl -s -H "Authorization: Bearer $ACCESS_TOKEN" \
        "https://www.googleapis.com/oauth2/v2/userinfo")

    echo "$response" | jq -r '.id'
}

get_student_submission_id() {
    local course_id="$1"
    local assignment_id="$2"
    local user_id="$3"
    local TOKENS_FILE="$SCRIPT_DIR/JSON/.classroom_tokens"
    local ACCESS_TOKEN
    ACCESS_TOKEN=$(jq -r .token "$TOKENS_FILE")
    local response
    response=$(curl -s -H "Authorization: Bearer $ACCESS_TOKEN" \
        "https://classroom.googleapis.com/v1/courses/$course_id/courseWork/$assignment_id/studentSubmissions")

    echo "$response" | jq -r --arg USER_ID "$user_id" '.studentSubmissions[] | select(.userId == $USER_ID) | .id'
}

load_or_refresh_assignment_map() {
    local course_name="$1"
    local course_id
    course_id=$(resolve_course_name_to_id "$course_name")
    local map_path="/tmp/.assignment_map_${course_id}"

    if [[ ! -f "$map_path" ]]; then
        log_and_echo INFO "Refreshing assignment map for $course_name"
        ./commands/list.sh --course "$course_name" -s >/dev/null
        if [[ ! -f "$map_path" ]]; then
            log_and_echo ERROR "Failed to load assignments for course '$course_name'"
            return 1
        fi
    fi
}

attach_drive_file_to_submission() {
    local course_id="$1"
    local coursework_id="$2"
    local submission_id="$3"
    local file_id="$4"
    local access_token="$5"

    local response
    response=$(curl -s -X POST \
        -H "Authorization: Bearer $access_token" \
        -H "Content-Type: application/json" \
        -d "{\"addAttachments\": [{\"driveFile\": {\"id\": \"$file_id\"}}]}" \
        "https://classroom.googleapis.com/v1/courses/$course_id/courseWork/$coursework_id/studentSubmissions/$submission_id:modifyAttachments")

    if echo "$response" | jq -e '.error' >/dev/null; then
        log_and_echo ERROR "Failed to attach file: $(echo "$response" | jq -r '.error.message')"
        return 1
    fi

    log_and_echo INFO "File attached successfully to submission."
    return 0
}

attach_link_to_submission() {
    local COURSE_ID="$1"
    local COURSEWORK_ID="$2"
    local SUBMISSION_ID="$3"
    local LINK_URL="$4"
    local ACCESS_TOKEN="$5"

    local RESPONSE
    RESPONSE=$(curl -s -X POST \
        -H "Authorization: Bearer $ACCESS_TOKEN" \
        -H "Content-Type: application/json" \
        -d '{"addAttachments": [{"link": {"url": "'"$LINK_URL"'"}}]}' \
        "https://classroom.googleapis.com/v1/courses/$COURSE_ID/courseWork/$COURSEWORK_ID/studentSubmissions/$SUBMISSION_ID:modifyAttachments")

    if echo "$RESPONSE" | jq -e '.error' >/dev/null; then
        log_and_echo ERROR "Failed to attach link: $(echo "$response" | jq -r '.error.message')"
        return 1
    else
        log_and_echo INFO "Link attached successfully to submission."
        return 0
    fi
}
