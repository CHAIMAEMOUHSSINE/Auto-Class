## type bash install.sh or ./install.sh to install dependency

## type autoclass -h for help
