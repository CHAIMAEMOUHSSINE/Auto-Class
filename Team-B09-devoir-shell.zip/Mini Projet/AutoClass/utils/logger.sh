#!/bin/bash

LOG_DIR="${LOG_DIR:-/var/log/AutoClass}"
LOG_FILE="$LOG_DIR/history.log"
USERNAME=$(whoami)

if [[ ! -d "$LOG_DIR" ]]; then
    mkdir -p "$LOG_DIR"
    chmod 777 "$LOG_DIR"
fi

if [[ ! -f "$LOG_FILE" ]]; then
    touch "$LOG_FILE"
    chmod 666 "$LOG_FILE"
fi

get_timestamp() {
    date "+%Y-%m-%d-%H-%M-%S"
}

log_info() {
    local message="$1"
    local timestamp
    timestamp=$(get_timestamp)
    echo "$timestamp : $USERNAME : INFOS : $message" >>"$LOG_FILE"
}

log_error() {
    local message="$1"
    local timestamp
    timestamp=$(get_timestamp)
    echo "$message" >&2
    echo "$timestamp : $USERNAME : ERROR : $message" >>"$LOG_FILE"
}

log_and_echo() {
    local level="$1"
    shift
    local message="$*"
    local timestamp
    timestamp=$(get_timestamp)

    case "$level" in
    INFO)
        echo "$message"
        echo "$timestamp : $USERNAME : INFOS : $message" >>"$LOG_FILE"
        ;;
    ERROR)
        echo "$message" >&2
        echo "$timestamp : $USERNAME : ERROR : $message" >>"$LOG_FILE"
        ;;
    *)
        echo "[Logger] Unknown log level: $level" >&2
        ;;
    esac
}
