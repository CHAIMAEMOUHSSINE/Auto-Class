#!/bin/bash

source "$SCRIPT_DIR/utils/logger.sh"
TOKENS_FILE="$SCRIPT_DIR/JSON/.classroom_tokens"
ACCESS_TOKEN=$(jq -r .token "$TOKENS_FILE")

RESPONSE=$(curl -s -X GET \
    "https://classroom.googleapis.com/v1/courses" \
    -H "Authorization: Bearer $ACCESS_TOKEN")

COURSE_MAP_FILE="$SCRIPT_DIR/JSON/course_map.json"
mkdir -p ./JSON

if echo "$RESPONSE" | jq -e '.error' >/dev/null; then
    log_and_echo ERROR "Failed to fetch courses:"
    log_and_echo ERROR "$RESPONSE" | jq
    exit 10
fi

echo "[AutoClass] Available Courses:"
echo "$RESPONSE" | jq -r '
    .courses[] | "\(.name) [\(.id)]"'

echo "$RESPONSE" | jq -r '
    .courses | map({key: .name, value: .id}) | from_entries
' >"$COURSE_MAP_FILE"

log_and_echo INFO "[AutoClass] Course map saved to $COURSE_MAP_FILE"
