#!/bin/bash

source "$SCRIPT_DIR/utils/logger.sh"

ADMIN_USER="root"
CONFIG_DIR="$SCRIPT_DIR/JSON"
LOG_FILE="/var/log/AutoClass/history.log"

if [[ "$USER" != "$ADMIN_USER" ]]; then
    echo "[Error] Only admin users can perform a full restore."
    exit 104
fi

echo "[Warning] This action will permanently delete all AutoClass configuration and credentials."
echo "This includes:"
echo " - $CONFIG_DIR (user preferences, tokens, mappings)"
echo " - $LOG_FILE (full history log)"
read -p "Are you sure you want to proceed? (yes/[no]) " confirm
if [[ "$confirm" != "yes" ]]; then
    echo "Aborted. No changes made."
    exit 0
fi

if [[ -d "$CONFIG_DIR" ]]; then
    echo "Deleting $CONFIG_DIR..."
    rm -rf "$CONFIG_DIR"
else
    echo "[Info] $CONFIG_DIR not found, skipping."
fi

if [[ -f "$LOG_FILE" ]]; then
    echo "Deleting $LOG_FILE..."
    sudo rm -f "$LOG_FILE"
else
    log_and_echo INFO "Log file not found at $LOG_FILE, skipping."
fi

echo "Restore complete. Run autoclass setup to reinitialize AutoClass."
