#!/bin/bash

source "$SCRIPT_DIR/utils.sh"
source "$SCRIPT_DIR/utils/logger.sh"

TOKENS_FILE="$SCRIPT_DIR/JSON/.classroom_tokens"
ACCESS_TOKEN=$(jq -r .token "$TOKENS_FILE")
CONFIG_FILE="$SCRIPT_DIR/JSON/config.json"

if [[ ! -f $CONFIG_FILE ]]; then
    log_and_echo ERROR "Missing config.json. Run setup first."
    exit 102
fi

SHOW_ASSIGNMENTS=true
SHOW_ANNOUNCEMENTS=true
SHOW_NO_DUE=false
SHOW_SIMPLE_LIST=false
COURSE_NAMES=()
DEADLINE_DAYS=$(jq -r '.deadline_warning_days' "$CONFIG_FILE")

while [[ "$#" -gt 0 ]]; do
    case "$1" in
    -c | --course)
        if [[ -z "$2" || "$2" == -* ]]; then
            log_and_echo ERROR "Missing parameter for $1"
            exit 103
        fi
        IFS=',' read -ra COURSE_NAMES <<<"$2"
        shift 2
        ;;
    -s | --simple)
        SHOW_SIMPLE_LIST=true
        shift
        ;;
    --announcements)
        SHOW_ASSIGNMENTS=false
        shift
        ;;
    --assignments)
        SHOW_ANNOUNCEMENTS=false
        shift
        ;;
    --days)
        if [[ -z "$2" || "$2" == -* ]]; then
            log_and_echo ERROR "Missing parameter for $1"
            exit 103
        fi
        DEADLINE_DAYS="$2"
        shift 2
        ;;
    --show-nodue)
        SHOW_NO_DUE=true
        shift
        ;;
    -h | --help)
        echo "Usage: list [-c|--course course1,course2] [-s|--simple] [--assignments] [--announcements] [--days N] [--show-nodue]"
        exit 0
        ;;
    *)
        log_and_echo INFO "[Warning] Unknown option: $1"
        shift
        ;;
    esac
done

if [[ ${#COURSE_NAMES[@]} -eq 0 ]]; then
    if [[ $(jq '.monitor_all_courses' "$CONFIG_FILE") == false ]]; then
        mapfile -t COURSE_NAMES < <(jq -r '.preferred_courses[]' "$CONFIG_FILE")
    else
        mapfile -t COURSE_NAMES < <(jq -r 'keys[]' "$SCRIPT_DIR/JSON/course_map.json")
    fi
fi

for course_name in "${COURSE_NAMES[@]}"; do
    COURSE_ID=$(resolve_course_name_to_id "$course_name")

    if [[ -z "$COURSE_ID" || "$COURSE_ID" == "null" ]]; then
        log_and_echo INFO "[Warning] Unknown course: $course_name"
        continue
    fi

    echo -e "\nCourse: $course_name"
    echo "---------------------------"

    if [[ "$SHOW_SIMPLE_LIST" == true ]]; then
        ID_FILE="/tmp/.assignment_map_${COURSE_ID}"
        : >"$ID_FILE"
        echo "Filtered Assignments in $course_name:"
        i=0

        RESPONSE=$(curl -s -H "Authorization: Bearer $ACCESS_TOKEN" \
            "https://classroom.googleapis.com/v1/courses/$COURSE_ID/courseWork")

        echo "$RESPONSE" | jq -c '.courseWork[]?' | while read -r item; do
            title=$(echo "$item" | jq -r '.title')
            course_work_id=$(echo "$item" | jq -r '.id')
            has_due=$(echo "$item" | jq -e '.dueDate' >/dev/null && echo true || echo false)

            if [[ "$has_due" == true ]]; then
                due=$(echo "$item" | jq -r '"\(.dueDate.year)-\(.dueDate.month)-\(.dueDate.day)"')
                if is_within_deadline "$due"; then
                    echo "[$i] $title"
                    echo "$course_work_id" >>"$ID_FILE"
                    ((i++))
                fi
            elif $SHOW_NO_DUE; then
                SUBMISSION_STATE=$(curl -s -H "Authorization: Bearer $ACCESS_TOKEN" \
                    "https://classroom.googleapis.com/v1/courses/$COURSE_ID/courseWork/$course_work_id/studentSubmissions" |
                    jq -r '.studentSubmissions[0].state // "UNKNOWN"')

                if [[ "$SUBMISSION_STATE" != "TURNED_IN" ]]; then
                    echo "[$i] $title"
                    echo "$course_work_id" >>"$ID_FILE"
                    ((i++))
                fi
            fi
        done
        exit 0
    else
        if $SHOW_ASSIGNMENTS; then
            echo -e "\nAssignments (due within $DEADLINE_DAYS days):"

            RESPONSE=$(curl -s -H "Authorization: Bearer $ACCESS_TOKEN" \
                "https://classroom.googleapis.com/v1/courses/$COURSE_ID/courseWork")

            course_work_id=$(echo "$item" | jq -r '.id')
            SUBMISSION_STATE=$(curl -s -H "Authorization: Bearer $ACCESS_TOKEN" \
                "https://classroom.googleapis.com/v1/courses/$COURSE_ID/courseWork/$course_work_id/studentSubmissions" |
                jq -r '.studentSubmissions[0].state // "UNKNOWN"')
            if [[ "$SUBMISSION_STATE" != "TURNED_IN" ]]; then
                echo "$RESPONSE" | jq -c '.courseWork[]?' | while read -r item; do
                    title=$(echo "$item" | jq -r '.title')
                    desc=$(echo "$item" | jq -r '.description // "None"')
                    has_due=$(echo "$item" | jq -e '.dueDate' >/dev/null && echo true || echo false)
                    links=$(echo "$item" | jq -r '[.materials[]? | select(.driveFile.driveFile.alternateLink != null) | .driveFile.driveFile.alternateLink] | @sh')

                    if [[ "$has_due" == true ]]; then
                        due=$(echo "$item" | jq -r '"\(.dueDate.year)-\(.dueDate.month)-\(.dueDate.day)"')
                        time=$(echo "$item" | jq -r 'try "\(.dueTime.hours // 0):\(.dueTime.minutes // 0)" catch "N/A"')

                        if is_within_deadline "$due"; then

                            echo -e "\nTitle: $title"
                            echo "Due: $due $time"
                            echo "Description: $desc"
                            [[ -n "$links" ]] && echo "Attachment: $links"
                            echo "---------------------------"
                        fi
                    elif $SHOW_NO_DUE; then

                        echo -e "\nTitle: $title"
                        echo "Due: No Due Date"
                        echo "Description: $desc"
                        [[ -n "$links" ]] && echo "Attachment: $links"
                        echo "---------------------------"
                    fi
                done
            fi
        fi

        if $SHOW_ANNOUNCEMENTS; then
            echo -e "\nAnnouncements (last $DEADLINE_DAYS days):"
            curl -s \
                -H "Authorization: Bearer $ACCESS_TOKEN" \
                "https://classroom.googleapis.com/v1/courses/$COURSE_ID/announcements" |
                jq -c '.announcements[]?' | while read -r announcement; do
                update_time=$(echo "$announcement" | jq -r '.updateTime')
                formatted_time=$(date -d "$update_time" "+%Y-%m-%d %H:%M:%S")
                if is_within_last_n_days "$update_time" "$DEADLINE_DAYS"; then
                    title_line=$(echo "$announcement" | jq -r '.text | split("\n") | .[0]')
                    full_text=$(echo "$announcement" | jq -r '.text')
                    links=$(echo "$announcement" | jq -r '[.materials[]? | select(.driveFile.driveFile.alternateLink != null) | .driveFile.driveFile.alternateLink] | @sh')
                    echo -e "\nTitle: $title_line"
                    echo "Updated: $formatted_time"
                    echo -e "$full_text"
                    [[ -n "$links" ]] && echo "Attachment: $links"
                    echo "---------------------------"
                fi
            done
        fi
    fi
done
