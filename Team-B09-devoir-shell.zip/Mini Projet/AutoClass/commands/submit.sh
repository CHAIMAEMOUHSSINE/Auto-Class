#!/bin/bash

source "$SCRIPT_DIR/utils.sh"
source "$SCRIPT_DIR/utils/logger.sh"

TOKENS_FILE="$SCRIPT_DIR/JSON/.classroom_tokens"
ACCESS_TOKEN=$(jq -r .token "$TOKENS_FILE")

COURSE_NAME=""
ASSIGNMENT_INDEX=""
MATERIALS=()
MODE="submit"

while [[ "$#" -gt 0 ]]; do
    case "$1" in
    -c | --course)
        COURSE_NAME="$2"
        shift 2
        ;;
    -i | --index)
        ASSIGNMENT_INDEX="$2"
        shift 2
        ;;
    -f | --file)
        FILE_PATH="$2"
        if [[ ! -f "$FILE_PATH" ]]; then
            log_and_echo ERROR "File not found: $FILE_PATH"
            exit 102
        fi

        FILE_ID=$(upload_file_to_drive "$FILE_PATH")
        if [[ -z "$FILE_ID" ]]; then
            log_and_echo ERROR "Failed to upload: $FILE_PATH"
            exit 101
        fi

        log_info "Uploaded: $FILE_PATH -> $FILE_ID"
        MATERIALS+=("{\"driveFile\": {\"id\": \"$FILE_ID\"}}")
        shift 2
        ;;
    -l | --link)
        LINK_URL="$2"
        if [[ ! "$LINK_URL" =~ ^https?:// ]]; then
            log_and_echo ERROR "Invalid URL: $LINK_URL"
            exit 100
        fi

        log_and_echo INFO "Added link: $LINK_URL"
        MATERIALS+=("{\"link\": {\"url\": \"$LINK_URL\"}}")
        shift 2
        ;;
    -v | --view)
        echo "Current attached materials:"
        for m in "${MATERIALS[@]}"; do
            echo "$m"
        done
        exit 0
        ;;
    -u | --unsubmit)
        MODE="unsubmit"
        shift
        ;;
    -h | --help)
        echo "Usage: submit -c \"course_name\" -i assignment_index [--file \"file_path\"] [--link url] [--unsubmit]"
        exit 0
        ;;
    *)
        log_and_echo INFO "[Warning] Unknown option: $1"
        shift
        ;;
    esac
done

if [[ -z "$COURSE_NAME" || -z "$ASSIGNMENT_INDEX" ]]; then
    log_and_echo ERROR "Course name and assignment index are required."
    exit 103
fi

if ! load_or_refresh_assignment_map "$COURSE_NAME"; then
    log_and_echo ERROR "Could not find courses"
    exit 103
fi

COURSE_ID=$(resolve_course_name_to_id "$COURSE_NAME")
ASSIGNMENT_ID=$(resolve_assignment_index_to_id "$ASSIGNMENT_INDEX" "$COURSE_ID")
USER_ID=$(get_logged_in_user_id)
SUBMISSION_ID=$(get_student_submission_id "$COURSE_ID" "$ASSIGNMENT_ID" "$USER_ID")

if [[ -z "$SUBMISSION_ID" || "$SUBMISSION_ID" == "null" ]]; then
    log_and_echo ERROR "Unable to get submission ID. Are you enrolled in this course?"
    exit 103
fi

SUBMISSION_STATE=$(curl -s -H "Authorization: Bearer $ACCESS_TOKEN" \
    "https://classroom.googleapis.com/v1/courses/$COURSE_ID/courseWork/$ASSIGNMENT_ID/studentSubmissions" |
    jq -r '.studentSubmissions[0].state')

if [[ "$SUBMISSION_STATE" == "TURNED_IN" ]]; then
    echo "[WARNING] This assignment has already been submitted."
    read -p "Do you want to unsubmit it before re-submitting? (y/n): " choice
    if [[ "$choice" == "y" || "$choice" == "Y" ]]; then
        echo "[INFO] Unsubmitting assignment first..."
        curl -s -X POST -H "Authorization: Bearer $ACCESS_TOKEN" \
            "https://classroom.googleapis.com/v1/courses/$COURSE_ID/courseWork/$ASSIGNMENT_ID/studentSubmissions/$SUBMISSION_ID:unsubmit" >/dev/null

        log_and_echo INFO "Unsubmitted. You can now proceed with your submission."
    else
        log_and_echo INFO "Submission cancelled to avoid duplicate submission."
        exit 0
    fi
fi

if [[ "$MODE" == "unsubmit" ]]; then
    if [[ "$SUBMISSION_STATE" == "TURNED_IN" ]]; then
        RESPONSE=$(curl -s -X POST \
            -H "Authorization: Bearer $ACCESS_TOKEN" \
            -H "Content-Type: application/json" \
            "https://classroom.googleapis.com/v1/courses/$COURSE_ID/courseWork/$ASSIGNMENT_ID/studentSubmissions/$SUBMISSION_ID/unsubmit")

        if [[ $? -eq 0 ]]; then
            log_and_echo INFO "Successfully unsubmitted the work."
        else
            log_and_echo ERROR "Failed to unsubmit."
        fi
    else
        log_and_echo INFO "[WARNING] This assignment has not been submitted yet. Can't unsubmit the work."
    fi
    exit 0
fi

echo
echo "====== Submission Summary ======"
echo "Course Name : $COURSE_NAME"
echo "Assignment Index: $ASSIGNMENT_INDEX"
echo "Attached Materials:"
i=1
for m in "${MATERIALS[@]}"; do
    if [[ -n "$FILE_PATH" ]]; then
        echo "[$i] $FILE_PATH"
    elif [[ -n "$LINK_URL" ]]; then
        echo "[$i] $LINK_URL"
    fi
    ((i++))
done
echo "================================"

read -p "Do you want to proceed with the submission? (y/n): " confirm
if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
    log_and_echo INFO "Submission cancelled."
    exit 0
fi

for material in "${MATERIALS[@]}"; do
    if echo "$material" | jq -e 'has("driveFile")' >/dev/null; then
        FILE_ID=$(echo "$material" | jq -r '.driveFile.id')
        attach_drive_file_to_submission "$COURSE_ID" "$ASSIGNMENT_ID" "$SUBMISSION_ID" "$FILE_ID" "$ACCESS_TOKEN"
    elif echo "$material" | jq -e 'has("link")' >/dev/null; then
        LINK=$(echo "$material" | jq -r '.link.url')
        attach_links_to_submission "$COURSE_ID" "$ASSIGNMENT_ID" "$SUBMISSION_ID" "$LINK" "$ACCESS_TOKEN"
    else
        log_and_echo INFO "Skipping non-drive material or invalid entry."
    fi
done

RESPONSE=$(curl -s -X POST \
    -H "Authorization: Bearer $ACCESS_TOKEN" \
    -H "Content-Type: application/json" \
    "https://classroom.googleapis.com/v1/courses/$COURSE_ID/courseWork/$ASSIGNMENT_ID/studentSubmissions/$SUBMISSION_ID/turnIn")

if [[ $? -eq 0 ]]; then
    log_and_echo INFO "Work successfully submitted!"
else
    log_and_echo ERROR "Submission failed."
fi
