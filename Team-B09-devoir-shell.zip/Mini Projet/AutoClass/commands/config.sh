#!/bin/bash

source "$SCRIPT_DIR/utils.sh"
source "$SCRIPT_DIR/utils/logger.sh"

CONFIG_FILE="$SCRIPT_DIR/JSON/config.json"

if [[ ! -f $CONFIG_FILE ]]; then
    log_and_echo ERROR "Missing config.json. Run setup first."
    exit 102
fi

SHOW_CONFIG=false
INTERACTIVE=false
NEW_COURSES=()
NEW_DEADLINE=""
NEW_AUTOCHECK=""

sanitize() {
    echo "$1" | sed "s/'//g; s/\`//g"
}

while [[ "$#" -gt 0 ]]; do
    case $1 in
    --show)
        SHOW_CONFIG=true
        ;;
    --interactive)
        INTERACTIVE=true
        ;;
    -c | --courses)
        IFS=',' read -ra NEW_COURSES <<<"$(sanitize "$2")"
        shift
        ;;
    -d | --days)
        NEW_DEADLINE="$2"
        shift
        ;;
    -a | --autocheck)
        NEW_AUTOCHECK="$2"
        shift
        ;;
    -h | --help)
        echo "Usage: config [--show] [--interactive] [-c course1,course2] [-d days] [-a true|false]"
        exit 0
        ;;
    *)
        log_and_echo INFO "[Warning] Unknown option: $1"
        ;;
    esac
    shift
done

if $SHOW_CONFIG; then
    echo -e "\nCurrent Configuration:"
    jq '.' "$CONFIG_FILE"
    exit 0
fi

if $INTERACTIVE; then
    echo -e "\n[Interactive Config Setup]"

    read -p "Enter preferred course names (comma-separated, or leave blank to keep existing): " input_courses
    if [[ -n "$input_courses" ]]; then
        IFS=',' read -ra NEW_COURSES <<<"$(sanitize "$input_courses")"
    fi

    read -p "Set deadline warning in days (leave blank to keep existing): " input_deadline
    [[ -n "$input_deadline" ]] && NEW_DEADLINE="$input_deadline"

    read -p "Enable auto-check on terminal start? (y/n, or leave blank): " input_autocheck
    [[ -n "$input_autocheck" ]] && NEW_AUTOCHECK="$input_autocheck"
fi

current_deadline=$(jq -r '.deadline_warning_days' "$CONFIG_FILE")
current_autocheck=$(jq -r '.auto_check_on_start' "$CONFIG_FILE")
current_courses=$(jq '.preferred_courses' "$CONFIG_FILE")
monitor_all=$(jq -r '.monitor_all_courses' "$CONFIG_FILE")

: "${NEW_DEADLINE:=$current_deadline}"
: "${NEW_AUTOCHECK:=$current_autocheck}"
resolved_courses_json="$current_courses"

if [[ ${#NEW_COURSES[@]} -gt 0 ]]; then
    RESOLVED_IDS=()
    for course in "${NEW_COURSES[@]}"; do
        id=$(resolve_course_name_to_id "$course")
        if [[ -n "$id" && "$id" != "null" ]]; then
            RESOLVED_IDS+=("\"$course\"")
        else
            log_and_echo INFO "[Warning] Unknown course name: $course"
        fi
    done
    resolved_courses_json=$(printf '%s\n' "${RESOLVED_IDS[@]}" | jq -s '.')
fi

if [[ ${#RESOLVED_IDS[@]} -eq 0 ]]; then
    monitor_all=true
else
    monitor_all=false
fi

if [[ "$NEW_AUTOCHECK" == "false" ]]; then
    sed -i "/if \[ -x \"$SCRIPT_DIR\/autoclass\.sh\" \]; then/,/fi/d" ~/.bashrc
else
    AUTOSTART_CMD="if [ -x \"$SCRIPT_DIR/autoclass.sh\" ]; then
    \"$SCRIPT_DIR/autoclass.sh\" list --show-nodue
fi"
    if ! grep -Fq "$SCRIPT_DIR/autoclass.sh" ~/.bashrc; then
        echo -e "$AUTOSTART_CMD" >>~/.bashrc
        log_info "Added AutoClass to startup in .bashrc"
    else
        log_info "AutoClass startup command already in .bashrc"
    fi

    source ~/.bashrc
fi
jq -n \
    --argjson deadline "$NEW_DEADLINE" \
    --argjson autocheck "$NEW_AUTOCHECK" \
    --argjson courses "$resolved_courses_json" \
    --argjson monitor_all "$monitor_all" \
    '{
        deadline_warning_days: $deadline,
        auto_check_on_start: $autocheck,
        preferred_courses: $courses,
        monitor_all_courses: $monitor_all
    }' >"$CONFIG_FILE"

log_and_echo INFO "Config file updated successfully."
