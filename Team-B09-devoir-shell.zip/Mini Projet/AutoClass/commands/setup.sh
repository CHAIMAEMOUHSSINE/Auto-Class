#!/bin/bash

source "$SCRIPT_DIR/utils.sh"
source "$SCRIPT_DIR/utils/logger.sh"

JSON_DIR="$SCRIPT_DIR/JSON"
CLASSROOM_TOKENS="$JSON_DIR/.classroom_tokens"

if [[ ! -d "$JSON_DIR" ]]; then
    mkdir -p "$JSON_DIR"
    chmod 700 "$JSON_DIR"
fi

if [[ ! -f "$CLASSROOM_TOKENS" ]]; then
    touch "$CLASSROOM_TOKENS"
    chmod 600 "$CLASSROOM_TOKENS"
fi

log_and_echo INFO "[AutoClass] Starting setup..."
log_and_echo INFO "[AutoClass] Launching Google authentication..."
source "$SCRIPT_DIR/venv/bin/activate"
python3 "$SCRIPT_DIR/auth.py"

if [[ $? -ne 0 ]]; then
    log_and_echo ERROR "Authentication failed. Aborting setup."
    exit 101
fi

log_and_echo INFO "[AutoClass] Authentication successful."

CONFIG_FILE="$JSON_DIR/config.json"

echo "[AutoClass] Fetching your courses..."
./utils/list_courses.sh

if [[ $? -ne 0 ]]; then
    log_and_echo ERROR "Failed to fetch course list."
    exit 103
fi

read -p "Enter the number of days before deadline to show upcoming assignments (default: 3): " deadline_limit
deadline_limit=${deadline_limit:-3}

read -p "Enter preferred course names to monitor (comma-separated, or leave blank to monitor all): " course_names
IFS=',' read -ra NAME_LIST <<<"$course_names"

monitor_all=false
RESOLVED_IDS=()

for name in "${NAME_LIST[@]}"; do
    id=$(resolve_course_name_to_id "$name")

    if [[ "$id" == "null" ]]; then
        log_and_echo INFO "[Warning] Course '$name' not found in map. Skipping."
    else
        RESOLVED_IDS+=("$id")
    fi
done

if [[ ${#RESOLVED_IDS[@]} -eq 0 ]]; then
    monitor_all=true
fi

read -p "Do you want to automatically check for assignments at terminal startup? (y/n): " auto_check
auto_check=${auto_check,,}
[[ "$auto_check" == "y" ]] && auto_check=true || auto_check=false

if [[ $auto_check == true ]]; then
    AUTOSTART_CMD="if [ -x \"$SCRIPT_DIR/autoclass.sh\" ]; then
    \"$SCRIPT_DIR/autoclass.sh\" list --show-nodue
fi"
    if ! grep -Fq "$SCRIPT_DIR/autoclass.sh" ~/.bashrc; then
        echo -e "$AUTOSTART_CMD" >>~/.bashrc
        log_info "Added AutoClass to startup in .bashrc"
    else
        log_info "AutoClass startup command already in .bashrc"
    fi

    source ~/.bashrc
fi

mkdir -p ./JSON

jq -n \
    --argjson deadline "$deadline_limit" \
    --argjson auto "$auto_check" \
    --argjson course_names "$(printf '%s\n' "${NAME_LIST[@]}" | jq -R . | jq -s .)" \
    --argjson monitor_all "$monitor_all" \
    '{
        deadline_warning_days: $deadline,
        auto_check_on_start: $auto,
        preferred_courses: $course_names,
        monitor_all_courses: $monitor_all
    }' >"$CONFIG_FILE"

log_and_echo INFO "[AutoClass] Configuration saved to $CONFIG_FILE"
