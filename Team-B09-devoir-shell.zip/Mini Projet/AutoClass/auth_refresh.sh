#!/bin/bash

source "$SCRIPT_DIR/utils/logger.sh"

TOKEN_FILE="$SCRIPT_DIR/JSON/.classroom_tokens"

token=$(jq -r '.token' "$TOKEN_FILE")
refresh_token=$(jq -r '.refresh_token' "$TOKEN_FILE")
token_uri=$(jq -r '.token_uri' "$TOKEN_FILE")
client_id=$(jq -r '.client_id' "$TOKEN_FILE")
client_secret=$(jq -r '.client_secret' "$TOKEN_FILE")
expiry=$(jq -r '.expiry' "$TOKEN_FILE")

expiry_ts=$(date -d "$expiry" +%s)
now_ts=$(date +%s)

if [ "$now_ts" -ge "$((expiry_ts - 60))" ]; then
    log_and_echo INFO "Refreshing token..."

    response=$(curl -s \
        -X POST "$token_uri" \
        -d client_id="$client_id" \
        -d client_secret="$client_secret" \
        -d refresh_token="$refresh_token" \
        -d grant_type=refresh_token)

    new_token=$(echo "$response" | jq -r '.access_token')
    new_expiry=$(date -d "now + $(echo "$response" | jq -r '.expires_in') seconds" --iso-8601=seconds)

    jq --arg token "$new_token" \
        --arg expiry "$new_expiry" \
        '.token = $token | .expiry = $expiry' \
        "$TOKEN_FILE" >"$TOKEN_FILE.tmp" && mv "$TOKEN_FILE.tmp" "$TOKEN_FILE"

    token="$new_token"
    log_and_echo INFO "Token refreshed."
fi

chmod 600 "$TOKEN_FILE"
export CLASSROOM_TOKEN="$token"
