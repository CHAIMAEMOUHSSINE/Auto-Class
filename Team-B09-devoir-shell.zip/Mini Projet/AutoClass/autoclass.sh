#!/bin/bash

MODE="normal"
LOG_DIR="/var/log/AutoClass"
SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do
    DIR="$(cd -P "$(dirname "$SOURCE")" >/dev/null 2>&1 && pwd)"
    SOURCE="$(readlink "$SOURCE")"
    [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
done
SCRIPT_DIR="$(cd -P "$(dirname "$SOURCE")" >/dev/null 2>&1 && pwd)"
export SCRIPT_DIR
export LOG_DIR

source "$SCRIPT_DIR/utils/logger.sh"

show_help() {
    cat <<EOF
AutoClass - Automate your Google Classroom workflow

Usage: autoclass [COMMAND] [OPTIONS]

Commands:
  setup             Configure user credentials (first time)
  list              List assignments (by course, due date, etc.)
  submit            Submit an assignment with attached files/links
  config            Set deadlines, filters, and preferences
  restore           Reset to default config (admin only)
  install           Installing packages and initial configuration

Flags:
  -h                Show this help message
  -f                Run using fork (sub-process)
  -t                Run using threads (where applicable)
  -s                Run in a subshell
  -l [DIR]          Log output to given directory
  -r                Restore default config (admin only)
EOF
}

run_api_command() {
    if should_refresh_token; then
        "$SCRIPT_DIR/auth_refresh.sh" || {
            log_and_echo ERROR "Failed to refresh token."
            exit 101
        }
    fi

    local cmd="$1"
    shift

    case "$MODE" in
    fork)
        run_func "$cmd" "$@" &
        log_and_echo INFO "Running '$cmd' in fork mode (background, PID $!)."
        ;;
    thread)
        (run_func "$cmd" "$@") &
        log_and_echo INFO "Running '$cmd' in thread mode (subshell + background, PID $!)."
        wait $!
        ;;
    subshell)
        (run_func "$cmd" "$@")
        log_and_echo INFO "Running '$cmd' in subshell mode."
        ;;
    normal)
        run_func "$cmd" "$@"
        ;;
    *)
        log_and_echo ERROR "Invalid mode: $MODE"
        exit 100
        ;;
    esac
}

run_func() {
    "$SCRIPT_DIR/commands/$1.sh" "${@:2}"
}

while getopts ":hftsl:r" opt; do
    case $opt in
    h)
        show_help
        exit 0
        ;;
    f) MODE="fork" ;;
    t) MODE="thread" ;;
    s) MODE="subshell" ;;
    l)
        LOG_DIR="$OPTARG"
        export LOG_DIR
        ;;
    r)
        "$SCRIPT_DIR/commands/restore.sh" "$@"
        exit 0
        ;;
    \?)
        log_and_echo ERROR "Invalid option: -$OPTARG"
        log_and_echo INFO "Use -h for help."
        exit 100
        ;;
    esac
done

source "$SCRIPT_DIR/utils.sh"

shift $((OPTIND - 1))

COMMAND=$1
shift

if [[ -n "$COMMAND" ]]; then
    case "$COMMAND" in
    list | submit | config)
        run_api_command "$COMMAND" "$@"
        ;;
    setup)
        "$SCRIPT_DIR/commands/setup.sh"
        ;;
    restore)
        "$SCRIPT_DIR/commands/restore.sh"
        ;;
    install)
        "$SCRIPT_DIR/install.sh"
        ;;
    *)
        log_and_echo ERROR "Unknown command: $COMMAND"
        log_and_echo INFO "Use -h for help."
        exit 100
        ;;
    esac
else
    show_help
fi
