import json
from google_auth_oauthlib.flow import InstalledAppFlow

SCOPES = [
"https://www.googleapis.com/auth/drive.readonly", 
"https://www.googleapis.com/auth/classroom.coursework.students", 
"https://www.googleapis.com/auth/classroom.courses.readonly", 
"https://www.googleapis.com/auth/classroom.student-submissions.me.readonly",
"https://www.googleapis.com/auth/classroom.announcements.readonly",
"openid", 
"https://www.googleapis.com/auth/userinfo.profile",
"https://www.googleapis.com/auth/userinfo.email",
"https://www.googleapis.com/auth/drive.file"
]


def main():
    flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
    
    creds = flow.run_local_server(port=0)

    with open("./JSON/.classroom_tokens", "w") as f:
        f.write(json.dumps({
        "token": creds.token,
        "refresh_token": creds.refresh_token,
        "token_uri": creds.token_uri,
        "client_id": creds.client_id,
        "client_secret": creds.client_secret,
        "scopes": creds.scopes,
        "expiry": creds.expiry.isoformat() if creds.expiry else None
    }, indent=2))

    print("Tokens saved to .classroom_tokens")

if __name__ == "__main__":
    main()
